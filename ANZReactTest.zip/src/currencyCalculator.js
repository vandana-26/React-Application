export var currencyCalculator = [
  {
    base: "AUD",
    term: "USD",
    rate: 0.8371
  },
  {
    base: "CAD",
    term: "USD",
    rate: 0.8711
  },
  {
    base: "USD",
    term: "CNY",
    rate: 6.1715
  },
  {
    base: "EUR",
    term: "USD",
    rate: 1.2315
  },
  {
    base: "GBP",
    term: "USD",
    rate: 1.5683
  },
  {
    base: "NZD",
    term: "USD",
    rate: 0.775
  },
  {
    base: "USD",
    term: "JPY",
    rate: 119.95
  },
  {
    base: "EUR",
    term: "CZK",
    rate: 27.6028
  },
  {
    base: "EUR",
    term: "DKK",
    rate: 7.4405
  },
  {
    base: "EUR",
    term: "NOK",
    rate: 8.6651
  }
];
